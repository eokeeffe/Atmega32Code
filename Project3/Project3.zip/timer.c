/*
 * timer.c
 *
 * Created: 17/05/2013 21:28:37
 *  Author: evan
 */ 

