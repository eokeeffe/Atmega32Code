/*
 * memoryStats.h
 *
 * Created: 18/05/2013 22:42:54
 *  Author: evan
 */ 


#ifndef MEMORYSTATS_H_
#define MEMORYSTATS_H_

/*
return how many Bytes remain in the stack space
Done by counting from the heap -> stack
*/

int freeRam ();


#endif /* MEMORYSTATS_H_ */